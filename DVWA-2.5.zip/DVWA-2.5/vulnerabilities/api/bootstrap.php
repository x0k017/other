<?php
require 'vendor/autoload.php';

# use Src\UserController;

# This would set up the database and stuff if needed
